def click():
    print("click")

click()